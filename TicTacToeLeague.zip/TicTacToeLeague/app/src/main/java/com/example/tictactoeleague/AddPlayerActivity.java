package com.example.tictactoeleague;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddPlayerActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnAddPlayer;
    private EditText txtNewPlayer;
    private PlayerDB db;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_player);

        txtNewPlayer = findViewById(R.id.nameEditText);
        btnAddPlayer = findViewById(R.id.btnInsertPlayer);
        btnAddPlayer.setOnClickListener(this);

        db = new PlayerDB(this);
    }

    @Override
    public void onClick(View v){
        if(v.getId() == R.id.btnInsertPlayer){
            String newPlayer = txtNewPlayer.getText().toString().trim();
            if (!db.checkExists(this, newPlayer)){
                try {
                    db.insertPlayer(newPlayer);
                    txtNewPlayer.setText("");
                    Toast.makeText(this, newPlayer + " has been added", Toast.LENGTH_SHORT).show();
                }
                catch(Exception e){
                    e.printStackTrace();
                    Toast.makeText(this, "There's already a player named " + newPlayer + ". Please enter a different name", Toast.LENGTH_LONG).show();
                }
            }
            else{
                Toast.makeText(this, newPlayer  + "already exists in, please enter a different name", Toast.LENGTH_LONG).show();
            }
        }
    }

}

