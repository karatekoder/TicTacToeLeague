package com.example.tictactoeleague;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {

    Button aButtons[][] = new Button[3][3];

    boolean playerOneTurn = true;

    static int turnCount = 0;

    TextView txtTurn;
    TextView txtP1Score;
    TextView txtP2Score;

    static int p1Score;
    static int p2Score;

    static String player1Name;
    static String player2Name;

    PlayerDB db;
    Intent intent;

    String xP1;
    String xP2;

    String p1Victory;
    String p2Victory;

    String p1Turn;
    String p2Turn;

    Button btnSeeScoreboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tic_tac_toe);

        aButtons[0][0] = findViewById(R.id.btn1);
        aButtons[0][1] = findViewById(R.id.btn2);
        aButtons[0][2] = findViewById(R.id.btn3);
        aButtons[1][0] = findViewById(R.id.btn4);
        aButtons[1][1] = findViewById(R.id.btn5);
        aButtons[1][2] = findViewById(R.id.btn6);
        aButtons[2][0] = findViewById(R.id.btn7);
        aButtons[2][1] = findViewById(R.id.btn8);
        aButtons[2][2] = findViewById(R.id.btn9);
        Button btnReset = findViewById(R.id.btnNewGame);
        btnReset.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                btnResetClick();
            }
        });

        Button btnSeeScoreboard = findViewById(R.id.btnSeeScoreboard);
        btnSeeScoreboard.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(GameActivity.this, ScoreboardActivity.class));
            }
        });

        //link delegate to the layout

        for(int j = 0; j < 3; j++){
            for(int i =  0; i < 3; i++){
                aButtons[i][j].setOnClickListener(this);
                aButtons[i][j].setText("");
            }
        }

        txtTurn = findViewById(R.id.txtPlayerTurn);
        txtTurn.setText(player1Name);

        txtP1Score = findViewById(R.id.txtP1Score);
        txtP2Score = findViewById(R.id.txtP2Score);

        p1Score = 0;
        p2Score = 0;

        intent = getIntent();
        xP1 = getIntent().getStringExtra("player1");
        xP2 = getIntent().getStringExtra("player2");

        txtP1Score.setText(getIntent().getStringExtra("player1"));
        txtP2Score.setText(getIntent().getStringExtra("player2"));

        p1Victory = xP1 + " Wins!";
        p2Victory = xP2 + " Wins!";

        p1Turn = xP1 + "'s Turn";
        p2Turn = xP2 + "'s Turn";

        db = new PlayerDB(this);
    }

    //@Override
    public void onClick(View v){

        turnCount++;
        //do nothing if button already has text, circumvents need to use button disabled property
        if(!((Button) v).getText().toString().equals("")){
            return;
        }
        //set button text to X if player 1 is the active player
        if (playerOneTurn){
            ((Button) v).setText("X");
            ((Button) v).setFreezesText(true);
            playerOneTurn= false;
            //txtTurn.setText(getResources().getString(R.string.player_2_turn));
            txtTurn.setText(p2Turn);
        }
        //set button text to O if player 1 is not the active player (player 2 is active)
        else{
            ((Button) v).setText("O");
            ((Button) v).setFreezesText(true);
            playerOneTurn = true;
            //txtTurn.setText(getResources().getString(R.string.player_1_turn));
            txtTurn.setText(p1Turn);
        }

        if (((Button) v).getText().equals("NEW GAME")){
            newGame();
        }

        if (victoryChecker() != null) {
            if (victoryChecker().equals("p1")){
                //txtTurn.setText(getResources().getString(R.string.player_1_win));
                txtTurn.setText(p1Victory);
                txtTurn.setTextColor(Color.parseColor("#008000"));
                lockButtons();
                p1Score ++;
                try {
                    db.updatePlayer(xP1, "win");
                    db.updatePlayer(xP2, "loss");
                }
                catch (Exception e){
                   e.printStackTrace();
               }
            }
            else if (victoryChecker().equals("p2")){
                //txtTurn.setText(getResources().getString(R.string.player_2_win));
                txtTurn.setText(p2Victory);
                txtTurn.setTextColor(Color.parseColor("#008000"));
                lockButtons();
                p2Score++;
                try {
                    db.updatePlayer(xP1, "loss");
                    db.updatePlayer(xP2, "win");
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        //check for tie and set textview message to red font
        if (turnCount==9 && victoryChecker()==null){
            txtTurn.setText(getResources().getString(R.string.tie_game));
            txtTurn.setTextColor(Color.parseColor("#FF0000"));
            turnCount = 0;
            try {
                db.updatePlayer(xP1, "tie");
                db.updatePlayer(xP2, "tie");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public String victoryChecker(){

        // get text from all the buttons, and assign them to variables
        String btn1Text = (String) aButtons[0][0].getText();
        String btn2Text = (String) aButtons[0][1].getText();
        String btn3Text = (String) aButtons[0][2].getText();
        String btn4Text = (String) aButtons[1][0].getText();
        String btn5Text = (String) aButtons[1][1].getText();
        String btn6Text = (String) aButtons[1][2].getText();
        String btn7Text = (String) aButtons[2][0].getText();
        String btn8Text = (String) aButtons[2][1].getText();
        String btn9Text = (String) aButtons[2][2].getText();

        // these are all the win conditions, concatentate the strings to use in the next part
        String firstRow = btn1Text + btn2Text + btn3Text;
        String secondRow = btn4Text + btn5Text + btn6Text;
        String thirdRow = btn7Text + btn8Text + btn9Text;
        String firstCol = btn1Text + btn4Text + btn7Text;
        String secondCol = btn2Text + btn5Text + btn8Text;
        String thirdCol = btn3Text + btn6Text + btn9Text;
        String diagonal1 = btn1Text + btn5Text + btn9Text;
        String diagonal2 = btn3Text + btn5Text + btn7Text;

        //read the concatenated string and check if any of the win conditions have been fulfilled
        if (firstRow.equals("XXX") || secondRow.equals("XXX") || thirdRow.equals("XXX")
                || firstCol.equals("XXX") || secondCol.equals("XXX") || thirdCol.equals("XXX")
                || diagonal1.equals("XXX") || diagonal2.equals("XXX")){
            return "p1";
        }
        else if(firstRow.equals("OOO") || secondRow.equals("OOO") || thirdRow.equals("OOO")
                || firstCol.equals("OOO") || secondCol.equals("OOO") || thirdCol.equals("OOO")
                || diagonal1.equals("OOO") || diagonal2.equals("OOO")){
            return "p2";
        }
        else{
            return null;
        }


    }

    //loop through the buttons to reset their text property, as well as re-enable them, and reset counter
    private void newGame() {
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 3; i++) {
                aButtons[i][j].setText("");
                aButtons[i][j].setEnabled(true);
                turnCount = 0;
            }
        }
        //player one will be the first time in the new game, regardless of which player played last
        playerOneTurn = true;
        txtTurn.setText(getResources().getString(R.string.player_1_turn));
        txtTurn.setTextColor(Color.parseColor("#000000"));
        startActivity(new Intent(this, SelectPlayer1Activity.class));
        finish();
    }

    private void btnResetClick(){
        newGame();
    }

    //used to disable all of the buttons after a winner is declared
    private void lockButtons(){
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 3; i++) {
                aButtons[i][j].setEnabled(false);
            }
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
        intent.removeExtra("player1");
        intent.removeExtra("player2");
    }

    // @Override
    protected  void onSaveInstance(Bundle outState){
        super.onSaveInstanceState(outState);

//        outState.putInt();
    }
    protected void onRestoreInstance(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
    }
}
