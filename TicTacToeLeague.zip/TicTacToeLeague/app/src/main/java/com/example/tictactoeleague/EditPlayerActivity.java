package com.example.tictactoeleague;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class EditPlayerActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnUpdate;
    Button btnDelete;
    Button btnCancel;

    EditText editTextName;
    TextView txtPlayer;
    Intent intent;

    String player;

    PlayerDB db;

    AlertDialog adDeletePlayer;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_player);

        btnUpdate = findViewById(R.id.btnUpdatePlayer);
        btnDelete = findViewById(R.id.btnDeletePlayer);
        btnCancel = findViewById(R.id.btnCancel);

        btnUpdate.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

        intent = getIntent();
        editTextName = findViewById(R.id.nameEditText);
        txtPlayer = findViewById(R.id.txtPlayer);
        txtPlayer.setText(getIntent().getStringExtra("player"));

        player = getIntent().getStringExtra("player");

        db = new PlayerDB(this);

        builder = new AlertDialog.Builder(EditPlayerActivity.this)
                .setTitle("Delete Player")
                .setMessage("Are you sure you want to delete this player?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            db.DeletePlayer(player);
                            dialog.cancel();
                            startActivity(new Intent(EditPlayerActivity.this, ScoreboardActivity.class));
                            Toast.makeText(EditPlayerActivity.this, "Player has been deleted", Toast.LENGTH_LONG).show();
                            finish();
                        }catch (Exception e){
                            e.printStackTrace();
                            Toast.makeText(EditPlayerActivity.this, "Something went wrong when trying to delete this player", Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert);
    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnUpdatePlayer){
            if (db.checkExists(this, player)) {
                Toast.makeText(this, "Player with that name already exists", Toast.LENGTH_SHORT).show();
            }
            else{
                try{
                    db.updatePlayerName(player);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        else if(v.getId() == R.id.btnDeletePlayer){
            try {
                adDeletePlayer = builder.show();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        else if(v.getId() == R.id.btnCancel){
            startActivity(new Intent(EditPlayerActivity.this, ScoreboardActivity.class));
            finish();
        }
    }
}
