package com.example.tictactoeleague;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity {

    Button btnStartGame;
    Button btnScoreboard;
    Button btnSelPlayer1;
    Button btnSelPlayer2;
    Button btnAddPlayer;
    Button btnOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
        btnStartGame = findViewById(R.id.btnStartGame);
        btnScoreboard = findViewById(R.id.btnScoreboard);
        //btnSelPlayer1 = findViewById(R.id.btnSelPlayer1);
        //btnSelPlayer2 = findViewById(R.id.btnSelPlayer2);
        btnAddPlayer = findViewById(R.id.btnAddPlayer);
        btnOptions = findViewById(R.id.btnOptions);

        btnStartGame.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
            }
        });

        btnScoreboard.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainMenuActivity.this, ScoreboardActivity.class));
            }
        });

//        btnSelPlayer1.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
//            }
//        });
//        btnSelPlayer2.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));
//            }
//        });
        btnAddPlayer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainMenuActivity.this, AddPlayerActivity.class));
            }
        });
        btnOptions.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainMenuActivity.this, OptionsActivity.class));
            }
        });

    }


}
