package com.example.tictactoeleague;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

public class ScoreboardActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ListView playersListView;
    private PlayerDB db;

    String selectedPlayer;
    AdapterView.OnLongClickListener onLongClickListener;

    public Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scoreboard);
        playersListView = (ListView) findViewById(R.id.playerListView);
        playersListView.setOnItemClickListener(this);
        intent = new Intent(ScoreboardActivity.this, EditPlayerActivity.class);
        db = new PlayerDB(this);
        updateDisplay();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id){
        HashMap<String, String> playerInfo = (HashMap<String, String>) playersListView.getItemAtPosition(position);
        selectedPlayer = playerInfo.get("name");


        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra("player", selectedPlayer);
        startActivity(intent);
    }

    private void updateDisplay(){
        // create a List of Map<String, ?> objects
        ArrayList<HashMap<String, String>> data = db.getPlayersOrdered();

        // create the resource, from, and to variables
        int resource = R.layout.scoreboard_item;
        String[] from = {"name", "wins", "losses", "ties"};
        int[] to = {R.id.nameTextView, R.id.winsTextView, R.id.lossesTextView, R.id.tiesTextView};

        // create and set the adapter
        SimpleAdapter adapter =
                new SimpleAdapter(this, data, resource, from, to);
        playersListView.setAdapter(adapter);

    }

    //this will update the listview whenever this activity is re-opened
    @Override
    protected void onResume(){
        super.onResume();
        updateDisplay();
    }

}
