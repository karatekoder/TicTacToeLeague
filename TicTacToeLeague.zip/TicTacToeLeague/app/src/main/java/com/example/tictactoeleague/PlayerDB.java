package com.example.tictactoeleague;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

/* based off DB made by rHildred
 */
public class PlayerDB {
    // database constants
    public static final String DB_NAME = "player.sqlite";
    public static final int    DB_VERSION = 1;
    public static boolean eligible;
    private static class DBHelper extends SQLiteOpenHelper {

        public DBHelper(Context context, String name,
                        SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // create tables
            //made the name column unique because when updating a players score record
            //the method will take a name parameter, and if more than one player has the same name,
            //the method will be ineffective
            db.execSQL("CREATE TABLE players (id INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , " +
                    "name VARCHAR NOT NULL UNIQUE, " +
                    "wins INTEGER NOT NULL  DEFAULT 0, " +
                    "losses INTEGER NOT NULL  DEFAULT 0, " +
                    "ties INTEGER NOT NULL  DEFAULT 0)");
         }

        @Override
        public void onUpgrade(SQLiteDatabase db,
                              int oldVersion, int newVersion) {

            db.execSQL("DROP TABLE \"players\"");
            Log.d("Task list", "Upgrading db from version "
                    + oldVersion + " to " + newVersion);

            onCreate(db);
        }
    }

    // database and database helper objects
    private SQLiteDatabase db;
    private DBHelper dbHelper;

    // constructor
    public PlayerDB(Context context) {
        dbHelper = new DBHelper(context, DB_NAME, null, DB_VERSION);
        openWriteableDB();
        closeDB();

    }
    // private methods
    private void openReadableDB() {
        db = dbHelper.getReadableDatabase();
    }

    private void openWriteableDB() {
        db = dbHelper.getWritableDatabase();
    }

    private void closeDB() {
        if (db != null)
            db.close();
    }

    ArrayList<HashMap<String, String>> getPlayers(){
        ArrayList<HashMap<String, String>> data =
                new ArrayList<HashMap<String, String>>();
        openReadableDB();
        Cursor cursor = db.rawQuery("SELECT name, wins, losses, ties FROM players ORDER BY name",null );
        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("name", cursor.getString(0));
            map.put("wins", cursor.getString(1));
            map.put("losses", cursor.getString(2));
            map.put("ties", cursor.getString(3));
            data.add(map);
        }
        if (cursor != null)
            cursor.close();
        closeDB();

        return data;
    }

    ArrayList<HashMap<String, String>> getPlayersOrdered(){
        ArrayList<HashMap<String, String>> data =
                new ArrayList<HashMap<String, String>>();
        openReadableDB();
        Cursor cursor = db.rawQuery("SELECT name, wins, losses, ties FROM players ORDER BY wins DESC",null );
        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("name", cursor.getString(0));
            map.put("wins", cursor.getString(1));
            map.put("losses", cursor.getString(2));
            map.put("ties", cursor.getString(3));
            data.add(map);
        }
        if (cursor != null)
            cursor.close();
        closeDB();

        return data;
    }

    void insertPlayer(String sName)throws Exception {

        openWriteableDB();
        ContentValues content = new ContentValues();
        content.put("name", sName);
        long nResult = db.insert("players",null, content);
        if(nResult == -1) throw new Exception("no data");
        closeDB();
    }

    void updatePlayer(String sName, String result) throws Exception{
        openReadableDB();
        openWriteableDB();
        ContentValues content = new ContentValues();
        int newWins;
        int newLosses;
        int newTies;
        long nResult;

        String from[] = {"name", "wins", "losses", "ties"};
        String where = "name = ?";
        String[] whereArgs = new String[]{sName};
        Cursor cursor = db.query("players", from, where, whereArgs, null, null, null, null);

        while(cursor.moveToNext()){
            switch(result){
                case "win":
                    content.put("name", cursor.getString(cursor.getColumnIndex("name")));
                    newWins = cursor.getInt(cursor.getColumnIndex("wins")) + 1;
                    content.put("wins", newWins);
                    content.put("losses", cursor.getInt(cursor.getColumnIndex("losses")));
                    content.put("ties", cursor.getInt(cursor.getColumnIndex("ties")));
                    break;
                case "loss":
                    content.put("name", cursor.getString(cursor.getColumnIndex("name")).toString());
                    content.put("wins", cursor.getInt(cursor.getColumnIndex("wins")));
                    newLosses = cursor.getInt(cursor.getColumnIndex("losses")) + 1;
                    content.put("losses", newLosses);
                    content.put("ties", cursor.getInt(cursor.getColumnIndex("ties")));
                    break;
                case "tie":
                    content.put("name", cursor.getString(cursor.getColumnIndex("name")));
                    content.put("wins", cursor.getInt(cursor.getColumnIndex("wins")));
                    content.put("losses", cursor.getInt(cursor.getColumnIndex("losses")));
                    newTies = cursor.getInt(cursor.getColumnIndex("ties")) + 1;
                    content.put("ties", newTies);
                    break;
                default:
                    //
            }
            nResult = db.update("players", content, where, whereArgs);
            if (nResult == -1) throw new Exception("something went wrong");

        }cursor.close();
        closeDB();
    }

    void updatePlayerName(String newName) throws Exception{
        long nResult;
        openReadableDB();
        openWriteableDB();
        ContentValues content = new ContentValues();

        String from[] = {"name"};
        String where = "name = ?";
        String[] whereArgs = new String[]{newName};
        Cursor cursor = db.query("players", from, where, whereArgs, null, null, null, null);

        while(cursor.moveToNext()) {
            content.put("name", newName);
        }
        nResult = db.update("players", content, where, whereArgs);
        if (nResult == -1) throw new Exception("something went wrong");
        closeDB();
    }

    void DeletePlayer(String player) throws Exception{
        openWriteableDB();
        try {
            db.delete("players", "name = ?", new String[]{player});
        } catch (Exception e){
            e.printStackTrace();
        }
        closeDB();
    }

    public static boolean checkExists(Context context, String name){

        DBHelper dbHelper = new DBHelper(context, DB_NAME, null, DB_VERSION);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        boolean exists = false;

        try{
            String query = "SELECT * FROM players WHERE name =" + name;
            Cursor c = db.rawQuery(query, null);
            exists = (c.getCount() > 0);
            c.close();
        }
        catch (SQLException e){
            db.close();
        }
        return exists;
    }

    void resetDB(){
        openWriteableDB();
        db.execSQL("delete from players");
        db.delete("players", null, null);
        db.close();
    }
}

