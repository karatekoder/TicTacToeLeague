package com.example.tictactoeleague;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class SelectPlayer2Activity extends Activity implements AdapterView.OnItemClickListener {

    ListView playersListView2;
    PlayerDB db;
    Intent intent;
    String selectedPlayer2;
    String p1name;

    Intent gameIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_player_2);
        playersListView2 = (ListView) findViewById(R.id.player2ListView);

        db = new PlayerDB(this);

       intent = getIntent();

        updateDisplay();

        gameIntent = new Intent(this, GameActivity.class);
        playersListView2.setOnItemClickListener(this);
    }



    @Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
        HashMap<String, String> playerInfo = (HashMap<String, String>) playersListView2.getItemAtPosition(position);
        selectedPlayer2 = playerInfo.get("name");

        //check that 2nd player is different from first
        intent = getIntent();
        p1name = getIntent().getStringExtra("player1");

            if (!p1name.equals(selectedPlayer2)) {
                try {
                    gameIntent.setAction(Intent.ACTION_SEND);
                    gameIntent.putExtra("player1", p1name);
                    gameIntent.putExtra("player2", selectedPlayer2);
                    gameIntent.setType("text/plain");
                    startActivity(gameIntent);
                    finish();
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(this, "2nd Player must be different from 1st Player", Toast.LENGTH_SHORT);
                }
            } else {
                Toast.makeText(this, "2nd Player must be different from 1st Player", Toast.LENGTH_SHORT);
            }
        }

    private void updateDisplay(){
        // create a List of Map<String, ?> objects
        ArrayList<HashMap<String, String>> data = db.getPlayers();

        // create the resource, from, and to variables
        int resource = R.layout.select_player_2_item;
        String[] from = {"name", "wins", "losses", "ties"};
        int[] to = {R.id.nameTextView, R.id.winsTextView, R.id.lossesTextView, R.id.tiesTextView};

        // create and set the adapter
        SimpleAdapter adapter =
                new SimpleAdapter(this, data, resource, from, to);
        playersListView2.setAdapter(adapter);
    }

    @Override
    protected void onResume(){
        super.onResume();
        updateDisplay();
    }
}
