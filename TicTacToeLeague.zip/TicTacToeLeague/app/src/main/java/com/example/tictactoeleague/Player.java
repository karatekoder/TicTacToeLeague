package com.example.tictactoeleague;

public class Player {

    private int playerId;
    private String name;
    private int wins;
    private int losses;
    private int ties;

    public Player(){
        name = "";
        wins = 0;
        losses = 0;
        ties = 0;
    }

    public Player(int playerId, String name, int wins, int losses, int ties){
        this.playerId = playerId;
        this.name = name;
        this.wins = wins;
        this.losses = losses;
        this.ties = ties;
    }

    public int getPlayerId(){
        return playerId;
    }
}
