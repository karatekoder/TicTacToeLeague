package com.example.tictactoeleague;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class OptionsActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnReset;
    private PlayerDB db;
    AlertDialog adReset;
    AlertDialog.Builder builder;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.options);

        btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(this);

        context = this;

        db = new PlayerDB(this);

        builder = new AlertDialog.Builder(OptionsActivity.this)
                .setTitle("Clear Database")
                .setMessage("Are you sure you want to clear the database?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        db.resetDB();
                        dialog.cancel();
                        startActivity(new Intent(OptionsActivity.this, MainMenuActivity.class));
                        Toast.makeText(OptionsActivity.this, "Database has been reset", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert);
    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnReset){
            //db.resetDB();
            adReset = builder.show();

        }
    }
}
