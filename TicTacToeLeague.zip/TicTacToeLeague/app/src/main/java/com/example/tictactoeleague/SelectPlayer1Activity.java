package com.example.tictactoeleague;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class SelectPlayer1Activity extends Activity implements OnItemClickListener{
    ListView playersListView;
    PlayerDB db;
    public Intent intent;
    String selectedPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_player_1);
        playersListView = (ListView) findViewById(R.id.player1ListView);

        db = new PlayerDB(this);

        intent = new Intent(this, SelectPlayer2Activity.class);

        updateDisplay();
        playersListView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id){

        HashMap<String, String> playerInfo = (HashMap<String, String>) playersListView.getItemAtPosition(position);
        selectedPlayer = playerInfo.get("name");
        intent.setAction(Intent.ACTION_SEND);
        intent.putExtra("player1", selectedPlayer);
        intent.setType("text/plain");

        try {
            startActivity(intent);
            finish();
        }
        catch(Exception e){
            e.printStackTrace();
            Log.e("errr: ", "failed to open act2");
        }
    }

    private void updateDisplay(){
        // create a List of Map<String, ?> objects
        ArrayList<HashMap<String, String>> data = db.getPlayers();

        // create the resource, from, and to variables
        int resource = R.layout.select_player_1_item;
        String[] from = {"name", "wins", "losses", "ties"};
        int[] to = {R.id.nameTextView, R.id.winsTextView, R.id.lossesTextView, R.id.tiesTextView};

        // create and set the adapter
        SimpleAdapter adapter =
                new SimpleAdapter(this, data, resource, from, to);
        playersListView.setAdapter(adapter);
    }

    @Override
    protected void onResume(){
        super.onResume();
        updateDisplay();
        intent.setData(null);
    }
}
